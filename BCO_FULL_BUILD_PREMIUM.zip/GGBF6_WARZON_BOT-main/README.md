Telegram bot with OpenAI integration
GGBF6_WARZON_BOT/
README.md
main.py
requirements.txt
render.yaml 
.python-version
⸻

👑 BLACK CROWN OPS

Artificial Competitive Intelligence for FPS

Not a bot.
Not a coach.
A system that creates TOP-1 players.

⸻

WHAT IT IS

BLACK CROWN OPS — это искусственный разум,
созданный для соревновательных FPS.

Он не отвечает.
Он анализирует.

Он не подсказывает.
Он ведёт.

Это не помощник.
Это система формирования игрока,
способного удерживать результат на мировом уровне.

⸻

SUPPORTED WORLDS
	•	Warzone
	•	Black Ops 7
	•	Battlefield 6
	•	Zombies (full strategic world)

Каждый режим имеет собственную логику, пресеты и стратегические правила.

⸻

TWO MODES

🤝 TEAMMATE (default)

Живой, свободный стиль.
Как боец из твоего отряда.

Фокус:
	•	где тебя читают
	•	почему ты умираешь именно здесь
	•	что делать в следующем файте

Коротко. Жёстко. По ситуации.

⸻

📚 COACH (absolute control)

Режим элитного давления.

Я:
	•	перестраиваю мышление
	•	убираю хаос в решениях
	•	выстраиваю путь от текущего уровня до мирового TOP-1

Это не мотивация.
Это система доминирования.

⸻

BRAIN MODES
	•	Normal — стабильность
	•	Pro — ускорение
	•	Demon — максимальный рост без компромиссов

Режим влияет на глубину анализа и требования к исполнению.

⸻

ZOMBIES WORLD

Полноценная система прохождения:
	•	маршруты
	•	перки (порядок)
	•	оружие
	•	Pack-a-Punch
	•	пасхалки
	•	round-by-round стратегия
	•	причины вайпов

Без хаоса. Без рандома.

⸻

HOW TO START

Напиши одной строкой:

Game | input | current level | target level

Дальше — контроль на моей стороне. 😈

⸻

PHILOSOPHY

BLACK CROWN OPS не обещает результат.
Он создаёт игрока, способного его удерживать.

Если ты ищешь советы — это не сюда.
Если ты готов выполнять — система тебя доведёт.

⸻

Invite-only mindset.
No excuses.
Only execution. 👑
