from __future__ import annotations

from dataclasses import dataclass


@dataclass
class CoachOutput:
    text: str


def _pick_focus(msg: str) -> str:
    m = msg.lower()
    if any(k in m for k in ["аим", "aim", "метк", "трек", "отдач", "реакц"]):
        return "AIM"
    if any(k in m for k in ["мув", "movement", "слайд", "стрейф", "прыж", "бхоп", "уклон"]):
        return "MOVEMENT"
    if any(k in m for k in ["пози", "position", "ротац", "угол", "хайграунд", "пик", "пуш", "зона"]):
        return "POSITIONING"
    return "HYBRID"


def build_plan(game: str, device: str, diff: str, msg: str) -> CoachOutput:
    focus = _pick_focus(msg)

    header = f"🎯 Разбор (game={game.upper()} | input={device.upper()} | diff={diff.upper()})"
    diag = f"🧩 Фокус: {focus}"

    questions = (
        "Ответь 1 строкой:\n"
        "1) Где умер? (точка/ситуация)\n"
        "2) Чем убили? (AR/SMG/Sniper/Shotgun)\n"
        "3) Что делал за 3 секунды до смерти?\n"
    )

    drills = []
    if focus in ("AIM", "HYBRID"):
        drills += [
            "AIM: 10 мин трекинг → 5 мин флик → 5 мин контроль отдачи (одна пушка).",
            "AIM: правило — *стреляй только когда прицел уже “прилип”* (не спеши первым выстрелом).",
        ]
    if focus in ("MOVEMENT", "HYBRID"):
        drills += [
            "MOVEMENT: 10 мин — пик угла: wide→tight, всегда возвращайся в укрытие.",
            "MOVEMENT: правило — *движение = смена угла*, не бегай по прямой под прицелом.",
        ]
    if focus in ("POSITIONING", "HYBRID"):
        drills += [
            "POS: 5 мин — отметь 3 safe-угла (куда можно откатиться) перед файтом.",
            "POS: правило — *сначала позиция, потом дуэль* (врываемся только с преимуществом).",
        ]

    week = (
        "📅 План на 7 дней:\n"
        "Д1–Д2: 30 мин drills + 3 катки с одной целью\n"
        "Д3–Д4: 45 мин drills + VOD 1 смерти (пиши мне)\n"
        "Д5–Д7: 60 мин drills + ранговые/скримы\n"
        "Цель: уменьшить “бесплатные смерти” на 30%."
    )

    text = "\n\n".join([header, diag, questions, "🔥 Упражнения:", "\n".join(f"• {x}" for x in drills), week])
    return CoachOutput(text=text)
