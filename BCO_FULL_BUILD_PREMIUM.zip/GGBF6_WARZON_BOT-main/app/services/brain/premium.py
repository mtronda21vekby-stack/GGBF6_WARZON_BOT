# -*- coding: utf-8 -*-
from __future__ import annotations


PREMIUM_RULES = {
    "warzone": [
        "Топ-игроки стреляют только после ротации",
        "Высота важнее обзора",
        "Последние 2 круга — игра без лишних выстрелов",
    ],
    "bf6": [
        "Лучшие игроки давят только после utility",
        "Objective важнее K/D",
        "Сквад всегда выше соло-фрага",
    ],
    "bo7": [
        "Топы читают спавн на 5 секунд вперёд",
        "Каждый пик — с планом трейда",
        "Если сомневаешься — не пик",
    ],
}


def get_premium_tip(game: str) -> str:
    tips = PREMIUM_RULES.get(game)
    if not tips:
        return ""
    return "💎 PREMIUM INSIGHT:\n• " + "\n• ".join(tips)
