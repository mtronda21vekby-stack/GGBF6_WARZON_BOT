from enum import Enum


class Difficulty(str, Enum):
    NORMAL = "normal"
    PRO = "pro"
    DEMON = "demon"
