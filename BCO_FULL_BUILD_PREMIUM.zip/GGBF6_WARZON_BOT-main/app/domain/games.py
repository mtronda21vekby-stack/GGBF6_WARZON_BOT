from enum import Enum


class Game(str, Enum):
    WARZONE = "warzone"
    BF6 = "bf6"
    BO7 = "bo7"
