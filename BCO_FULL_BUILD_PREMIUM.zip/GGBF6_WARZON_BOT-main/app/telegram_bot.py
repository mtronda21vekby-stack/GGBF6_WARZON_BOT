# app/telegram_bot.py
raise RuntimeError(
    "Polling disabled. This project works ONLY via FastAPI webhook."
)