# app/worlds/zombies/__init__.py
# -*- coding: utf-8 -*-
from __future__ import annotations

from app.worlds.zombies.router import ZombiesWorld

__all__ = ["ZombiesWorld"]
