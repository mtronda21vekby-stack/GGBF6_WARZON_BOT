# app/worlds/zombies/presets.py
# -*- coding: utf-8 -*-
from __future__ import annotations

from typing import Any, Dict, List, Optional


# =========================================================
# HELPERS
# =========================================================
def _p(prof: Dict[str, Any], key: str, default: str = "") -> str:
    v = (prof or {}).get(key)
    s = "" if v is None else str(v).strip()
    return s if s else default


def _fmt(title: str, lines: List[str]) -> str:
    out = [title, ""]
    out.extend(lines)
    return "\n".join(out).strip()


def _ensure_profile(x: Any) -> Dict[str, Any]:
    """
    Роутер иногда передаёт 'Ashes'/'Astra' строкой.
    Приводим к профилю, чтобы всё работало стабильно.
    """
    if isinstance(x, dict):
        return x
    if isinstance(x, str) and x.strip():
        return {"zombies_map": x.strip()}
    return {"zombies_map": "Ashes"}


def _norm_map(profile_or_name: Any) -> str:
    prof = _ensure_profile(profile_or_name)
    m = _p(prof, "zombies_map", "Ashes").lower()
    return "Astra" if "astra" in m else "Ashes"


# =========================================================
# ZOMBIES — HUB / HOME
# (router ожидает zombies_hub_text)
# =========================================================
def zombies_hub_text(profile_or_name: Any) -> str:
    m = _norm_map(profile_or_name)
    return _fmt(
        "🧟 ZOMBIES — БАЗА (ультра-гайд)",
        [
            f"Текущая карта: {m}",
            "",
            "Выбери цель снизу 👇",
            "• 🗺 Карты — что за карта и куда бежать",
            "• ⚡ Перки — что брать и в каком порядке",
            "• 🔫 Оружие — чем реально проходить",
            "• 🥚 Пасхалки — логика шагов + когда делать",
            "• 🧠 Стратегия раундов — как жить долго",
            "• ⚡ Быстрые советы — если прямо сейчас умираешь",
            "",
            "Правило №1:",
            "«Открыть всё = умереть. Открыть умно = жить» 😈",
        ],
    )


def zombies_home_text(profile_or_name: Any) -> str:
    # совместимость (если где-то зовётся home)
    return zombies_hub_text(profile_or_name)


def zombies_maps_text(profile_or_name: Optional[Any] = None) -> str:
    return _fmt(
        "🗺 ZOMBIES — КАРТЫ",
        [
            "🧟 Ashes — проще для соло: позиционка + два выхода.",
            "🧟 Astra — темп/мувмент: лучше в коопе, на месте не стоять.",
            "",
            "Мини-выбор:",
            "• новичок соло → Ashes до ~20",
            "• хочешь темп/кооп → Astra",
        ],
    )


# =========================================================
# ASHES — CONTENT
# =========================================================
def ashes_overview_text(profile_or_name: Any) -> str:
    return _fmt(
        "🗺 ASHES — ОБЗОР",
        [
            "Тип: контроль + позиционка.",
            "Смерти: узко / зажим / спавн за спиной / жадность на двери.",
            "",
            "Скелет (быстро):",
            "1) 1–6: экономика, минимум дверей",
            "2) 7–10: питание + Jugger",
            "3) 11–20: Pack-a-Punch + контроль волны",
            "4) 20+: маршрут + дисциплина (не повторяй угол)",
            "",
            "Золотое правило:",
            "✅ Два выхода всегда. ❌ Один выход = смерть.",
        ],
    )


def ashes_perks_text(profile_or_name: Any) -> str:
    return _fmt(
        "⚡ ASHES — ПЕРКИ (порядок)",
        [
            "1️⃣ Jugger-Nog — must-have",
            "2️⃣ Stamin-Up — отходы/контроль дистанции",
            "3️⃣ Speed Cola — темп",
            "4️⃣ Quick Revive — соло страховка",
            "",
            "Ошибка №1:",
            "Speed Cola раньше Jugger = подписка на смерть.",
        ],
    )


def ashes_weapons_text(profile_or_name: Any) -> str:
    return _fmt(
        "🔫 ASHES — ОРУЖИЕ",
        [
            "Лучшее:",
            "• AR (урон за пулю + стабильность)",
            "• LMG (если есть место/отход)",
            "",
            "Не бери:",
            "• SMG с маленьким магазином (перезарядка = смерть)",
            "• Sniper (ты не в Warzone 😄)",
            "",
            "Pack-a-Punch:",
            "1) урон",
            "2) магазин/перезарядка",
            "3) удобство/контроль",
        ],
    )


def ashes_easter_egg_text(profile_or_name: Any) -> str:
    return _fmt(
        "🥚 ASHES — ПАСХАЛКА (логика)",
        [
            "Делай шаги на ‘последнем’ зомби.",
            "",
            "Шаги:",
            "1) Питание/основа",
            "2) Ключевые зоны (без жадности)",
            "3) Артефакты (лучше после 10 раунда)",
            "4) Подготовка: Jugger + Stamin + пап-ствол + патроны",
            "5) Финальный ивент",
            "",
            "Правило:",
            "Без Jugger + папа финал НЕ стартуй.",
        ],
    )


def ashes_strategy_text(profile_or_name: Any) -> str:
    return _fmt(
        "🧠 ASHES — СТРАТЕГИЯ РАУНДОВ",
        [
            "1–6: экономика, минимум дверей.",
            "7–12: питание → Jugger → стабильная позиция.",
            "13–20: линия + два выхода + микро-смещение.",
            "20+: маршрут, перезарядка только на отходе.",
            "",
            "Жёсткая правда:",
            "Стоишь = тебя читают = ты труп 😈",
        ],
    )


# =========================================================
# ASTRA — CONTENT
# =========================================================
def astra_overview_text(profile_or_name: Any) -> str:
    return _fmt(
        "🗺 ASTRA — ОБЗОР",
        [
            "Тип: мувмент + сплит волны.",
            "Смерти: остановился / ловушка / зажим на смене позиции.",
            "",
            "Скелет (быстро):",
            "1) 1–6: экономия, без лишних дверей",
            "2) 7–10: питание + Jugger + маршрут отхода",
            "3) 11–20: петля мувмента + пап-ствол",
            "4) 20+: дисциплина, шаги/покупки на последнем зомби",
            "",
            "Правило Astra:",
            "❌ Стоишь = умер. ✅ Двигаешься с планом = живёшь.",
        ],
    )


def astra_perks_text(profile_or_name: Any) -> str:
    return _fmt(
        "⚡ ASTRA — ПЕРКИ (порядок)",
        [
            "1️⃣ Jugger-Nog",
            "2️⃣ Stamin-Up",
            "3️⃣ Deadshot (если реально держишь голову)",
            "4️⃣ Speed Cola",
            "5️⃣ Quick Revive (соло/если часто падаешь)",
            "",
            "Если умираешь на смене позиции:",
            "Jugger → Stamin → Speed.",
        ],
    )


def astra_weapons_text(profile_or_name: Any) -> str:
    return _fmt(
        "🔫 ASTRA — ОРУЖИЕ",
        [
            "Лучшее:",
            "• SMG с большим магазином (мувмент важнее)",
            "• AR как стабильный второй ствол",
            "",
            "Кнопка паники:",
            "• Shotgun (сейвер)",
            "",
            "Не бери:",
            "• медленные LMG (умрёшь на повороте/перезарядке)",
            "",
            "Pack-a-Punch:",
            "1) удобство/скорость",
            "2) урон",
            "3) магазин",
        ],
    )


def astra_easter_egg_text(profile_or_name: Any) -> str:
    return _fmt(
        "🥚 ASTRA — ПАСХАЛКА (логика)",
        [
            "Делай шаги на ‘последнем’ зомби. Astra не прощает суету.",
            "",
            "Шаги:",
            "1) Порталы/питание",
            "2) Генераторы/синхронизация (оставь 1–2 зомби)",
            "3) Дефенд-фазы (кооп проще: 1 держит, 1 делает шаг)",
            "4) Подготовка: полный набор перков + пап-оружие + патроны",
            "5) Финальный ивент/босс",
            "",
            "Правило:",
            "Без Jugger + Stamin + папа финал НЕ стартуй.",
        ],
    )


def astra_strategy_text(profile_or_name: Any) -> str:
    return _fmt(
        "🧠 ASTRA — СТРАТЕГИЯ РАУНДОВ",
        [
            "1–6: экономия.",
            "7–12: питание → Jugger → маршрут отхода.",
            "13–20: петля мувмента, не застревай в узких.",
            "20+: дисциплина, шаги/покупки на последнем зомби.",
            "",
            "Самая частая смерть:",
            "«Я на секунду постою…» — и всё 😄",
        ],
    )


# =========================================================
# GLOBAL SCREENS
# =========================================================
def zombies_perks_text(profile_or_name: Any) -> str:
    return _fmt(
        "⚡ ZOMBIES — ПЕРКИ (база)",
        [
            "Must-have:",
            "• Jugger-Nog",
            "• Stamin-Up",
            "",
            "По ситуации:",
            "• Speed Cola — темп",
            "• Quick Revive — соло",
            "• Deadshot — если держишь голову",
        ],
    )


def zombies_weapons_text(profile_or_name: Any) -> str:
    return _fmt(
        "🔫 ZOMBIES — ОРУЖИЕ (база)",
        [
            "Старт: AR/SMG.",
            "Mid: 1 стабильный основной + 1 под ситуацию.",
            "Late: Pack-a-Punch + контроль перезарядки/позиции.",
        ],
    )


def zombies_easter_eggs_text(profile_or_name: Any) -> str:
    return _fmt(
        "🥚 ZOMBIES — ПАСХАЛКИ (база)",
        [
            "• Шаги на ‘последнем’ зомби",
            "• Финал не стартуем без перков + пап-оружия",
            "• В коопе: 1 держит волну, 1 делает шаг",
        ],
    )


def zombies_rounds_strategy_text(profile_or_name: Any) -> str:
    return _fmt(
        "🧠 ZOMBIES — СТРАТЕГИЯ РАУНДОВ (база)",
        [
            "1–6: экономика.",
            "7–10: питание + Jugger.",
            "11–20: Pack-a-Punch + контроль волны.",
            "20+: маршрут, дисциплина, шаги на последнем зомби.",
        ],
    )


def zombies_quick_tips_text(profile_or_name: Any) -> str:
    return _fmt(
        "⚡ ZOMBIES — БЫСТРЫЕ СОВЕТЫ",
        [
            "• Зажали → БЕГИ",
            "• Перезарядка только на отходе",
            "• Не загоняй себя в тупик",
            "• Последний зомби = время на покупки/шаги",
            "",
            "Хочешь точнее: карта | раунд | от чего падаешь | что открыл",
        ],
    )


# =========================================================
# ROUTER-COMPAT NAMES (ИМЕННО ТО, ЧТО ИМПОРТИРУЕТ ТВОЙ router.py)
# =========================================================
def zombies_map_overview_text(profile_or_name: Any) -> str:
    return astra_overview_text(profile_or_name) if _norm_map(profile_or_name) == "Astra" else ashes_overview_text(profile_or_name)


def zombies_map_perks_text(profile_or_name: Any) -> str:
    return astra_perks_text(profile_or_name) if _norm_map(profile_or_name) == "Astra" else ashes_perks_text(profile_or_name)


def zombies_map_loadout_text(profile_or_name: Any) -> str:
    # роутер называет "loadout", по факту это оружие
    return astra_weapons_text(profile_or_name) if _norm_map(profile_or_name) == "Astra" else ashes_weapons_text(profile_or_name)


def zombies_map_easter_eggs_text(profile_or_name: Any) -> str:
    # роутер ожидает plural: eggs
    return astra_easter_egg_text(profile_or_name) if _norm_map(profile_or_name) == "Astra" else ashes_easter_egg_text(profile_or_name)


def zombies_map_round_strategy_text(profile_or_name: Any) -> str:
    # роутер ожидает "round strategy" (по карте)
    return astra_strategy_text(profile_or_name) if _norm_map(profile_or_name) == "Astra" else ashes_strategy_text(profile_or_name)


def zombies_map_quick_tips_text(profile_or_name: Any) -> str:
    return zombies_quick_tips_text(profile_or_name)


# =========================================================
# EXTRA ALIASES (на будущее/совместимость)
# =========================================================
def zombies_map_weapons_text(profile_or_name: Any) -> str:
    return zombies_map_loadout_text(profile_or_name)


def zombies_map_easter_egg_text(profile_or_name: Any) -> str:
    return zombies_map_easter_eggs_text(profile_or_name)


def zombies_map_strategy_text(profile_or_name: Any) -> str:
    return zombies_map_round_strategy_text(profile_or_name)


def zombies_strategy_text(profile_or_name: Any) -> str:
    return zombies_map_round_strategy_text(profile_or_name)


def zombies_eggs_text(profile_or_name: Any) -> str:
    return zombies_easter_eggs_text(profile_or_name)


def zombies_rounds_text(profile_or_name: Any) -> str:
    return zombies_rounds_strategy_text(profile_or_name)
