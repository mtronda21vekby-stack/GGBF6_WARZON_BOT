# app/worlds/warzone/presets.py
# -*- coding: utf-8 -*-
from __future__ import annotations

from typing import Dict, Any


def _p(prof: Dict[str, Any], key: str, default: str) -> str:
    v = (prof or {}).get(key)
    return str(v).strip() if v else default


def _is_kbm(profile: Dict[str, Any]) -> bool:
    return _p(profile, "input", "Controller").upper() == "KBM"


def _diff(profile: Dict[str, Any]) -> str:
    d = _p(profile, "difficulty", "Normal")
    d_low = d.lower()
    if "demon" in d_low:
        return "Demon"
    if "pro" in d_low:
        return "Pro"
    return "Normal"


def _plat(profile: Dict[str, Any]) -> str:
    p = _p(profile, "platform", "PC")
    pl = p.lower()
    if "play" in pl:
        return "PlayStation"
    if "xbox" in pl:
        return "Xbox"
    return "PC"


def _role(profile: Dict[str, Any]) -> str:
    r = _p(profile, "role", "Flex").lower()
    if "slay" in r:
        return "Slayer"
    if "entry" in r or "энтри" in r:
        return "Entry"
    if "igl" in r:
        return "IGL"
    if "support" in r or "саппорт" in r:
        return "Support"
    return "Flex"


def _fmt(title: str, items: list[tuple[str, str]]) -> str:
    out = [title, ""]
    for i, (k, v) in enumerate(items, 1):
        out.append(f"{i}) {k}: {v}")
    return "\n".join(out).strip()


def _micro_test_block(diff: str) -> str:
    # “цифры на экране” + супер понятный тест
    if diff == "Demon":
        tempo = "быстрее, но не истерика"
    elif diff == "Pro":
        tempo = "быстро и стабильно"
    else:
        tempo = "медленно, но железно"

    return (
        "\n\n🧪 ТЕСТ 60 СЕК (микро-настройка без магии):\n"
        "1) Стреляй по боту/стене, потом трекинг по движущейся цели.\n"
        "2) Если ПЕРЕЛЁТ — уменьши (sens или ADS) на 0.05–0.10.\n"
        "3) Если НЕ ДОТЯГИВАЕШЬ — увеличь на 0.05–0.10.\n"
        "4) Меняй ТОЛЬКО 1 параметр за раз.\n"
        f"Темп режима: {tempo} 😈\n"
    )


def _checklist_block() -> str:
    return (
        "\n\n✅ ЧЕК-ЛИСТ (чтобы настройки реально работали):\n"
        "• 48 часов НЕ меняешь всё подряд (иначе мозг не адаптируется).\n"
        "• Deadzone: минимально без дрифта/дрожи.\n"
        "• Стабильность > “самая быстрая сенса на свете”.\n"
        "• Одинаковая дистанция руки/стула/монитора каждый день.\n"
        "• Если сегодня “не летит” — не трогай цифры, трогай сон 😄\n"
    )


# =========================
# WARZONE — ROLES (RU)
# =========================
def wz_role_setup_text(profile: Dict[str, Any]) -> str:
    role = _role(profile)
    diff = _diff(profile)
    plat = _plat(profile)
    inp = _p(profile, "input", "Controller")

    role_lines = {
        "Slayer": [
            "• Твоя задача: первые 2 килла → темп → пространство.",
            "• Не геройствуй 1v3: ты Slayer, а не “соло-мультфильм”.",
            "• После килла смещайся на 2–3 шага: тебя уже префаерят.",
        ],
        "Entry": [
            "• Твоя задача: открываешь файт, но НЕ умираешь бесплатно.",
            "• Входишь первым — да, но с инфой: граната/пинг/плечо-чек.",
            "• Если не можешь выйти живым — ты не Entry, ты “вход в лобби”.",
        ],
        "IGL": [
            "• Твоя задача: ротации/темп/решения (меньше паники — больше контроля).",
            "• Колл: 1 мысль = 1 фраза. Не лекция на 40 минут.",
            "• Ты живёшь дольше всех: мёртвый IGL — это “тишина в команде”.",
        ],
        "Support": [
            "• Твоя задача: комфорт и выживание команды.",
            "• Урон дал — отлично. Главная цель: чтобы тиммейт НЕ отлетел.",
            "• Ты не слабый — ты умный: делаешь победу дешевле.",
        ],
        "Flex": [
            "• Твоя задача: закрываешь дыры, подстраиваешься.",
            "• Если команда стоит — ты двигаешь. Если команда гонит — ты тормозишь.",
            "• Flex = адаптация. Не адаптируешься — ты “флексовый труп” 😄",
        ],
    }

    lines = "\n".join(role_lines.get(role, role_lines["Flex"]))

    return (
        "🎭 Warzone — Роль (RU)\n\n"
        f"Роль: {role} | Режим: {diff}\n"
        f"Платформа: {plat} | Input: {inp}\n\n"
        "Коротко по делу:\n"
        f"{lines}\n\n"
        "🧠 Мини-правило: если ты 2 раза подряд умираешь одинаково — это не “невезение”, это паттерн."
    )


# =========================
# WARZONE — AIM/SENS (RU) — С ЦИФРАМИ + тест + чеклист
# =========================
def wz_aim_sens_text(profile: Dict[str, Any]) -> str:
    diff = _diff(profile)
    plat = _plat(profile)
    role = _role(profile)

    # Режим влияет на “темп”, но не превращает тебя в “дёрганую камеру”
    if _is_kbm(profile):
        # KBM — реальные цифры зависят от ковра/мыши, но дадим мощный старт
        base_sens = "5.5"
        if diff == "Pro":
            base_sens = "6.2"
        if diff == "Demon":
            base_sens = "6.8"

        return (
            _fmt(
                "🎯 Warzone — Aim/Sens (KBM) (RU)\n"
                f"Платформа: {plat} | Роль: {role}\n"
                "База (копируй и не дергайся каждый матч):",
                [
                    ("DPI", "800 (альтернатива: 1600)"),
                    ("Polling Rate", "1000 Hz"),
                    ("Windows Enhance Pointer Precision", "OFF"),
                    ("In-game Sens (старт)", base_sens),
                    ("ADS Multiplier", "1.00 (старт), потом ±0.05"),
                    ("FOV", "110 (если close-range ад — 115–120)"),
                    ("Weapon Motion Blur", "OFF"),
                    ("World Motion Blur", "OFF"),
                ],
            )
            + _micro_test_block(diff)
            + _checklist_block()
            + "\n\n😄 Юмор: если ты меняешь сенсу 4 раза за вечер — ты не настраиваешь, ты гадаешь на мышке."
        )

    # Controller — важны конкретные цифры. Дадим три “пакета” под режим мозга.
    if diff == "Normal":
        sens = "6/6"
        low_ads = "0.80"
        mid_ads = "0.85"
        slope = "0.75"
        rmin = "0.03–0.06"
    elif diff == "Pro":
        sens = "7/7"
        low_ads = "0.85"
        mid_ads = "0.90"
        slope = "0.80"
        rmin = "0.03–0.06"
    else:
        sens = "8/8"
        low_ads = "0.90"
        mid_ads = "0.95"
        slope = "0.85"
        rmin = "0.04–0.07"

    return (
        _fmt(
            "🎯 Warzone — Aim/Sens (Controller) (RU)\n"
            f"Платформа: {plat} | Роль: {role} | Режим: {diff}\n"
            "Цифры (стартовая база, потом микротюнинг):",
            [
                ("FOV", "110 (close-range = 115–120)"),
                ("Sensitivity (Horiz/Vert)", sens),
                ("Aim Response Curve", "Dynamic (старт)"),
                ("ADS Mult (Low Zoom)", low_ads),
                ("ADS Mult (2x–3x)", mid_ads),
                ("Deadzone Left Stick Min", "0.00 → подними до исчезновения дрифта"),
                ("Deadzone Right Stick Min", rmin),
                ("Left Stick Max", "0.85"),
                ("Right Stick Max", "0.99"),
                ("Aim Assist", "ON (да, оставь)"),
            ],
        )
        + _micro_test_block(diff)
        + _checklist_block()
        + "\n\n🔥 Быстрый диагноз:\n"
          "• если трясёт прицел — R Min +0.01 или slope -0.05\n"
          "• если не успеваешь доводить — slope +0.05 или sens +1\n"
          "• если перелетаешь — ADS -0.05\n"
    )


# =========================
# WARZONE — CONTROLLER TUNING (RU) — С ЦИФРАМИ + тест + чеклист
# =========================
def wz_controller_tuning_text(profile: Dict[str, Any]) -> str:
    diff = _diff(profile)
    plat = _plat(profile)
    role = _role(profile)

    if diff == "Normal":
        slope = "0.75"
        rmin = "0.03–0.06"
    elif diff == "Pro":
        slope = "0.80"
        rmin = "0.03–0.06"
    else:
        slope = "0.85"
        rmin = "0.04–0.07"

    return (
        _fmt(
            "🎮 Warzone — Controller Tuning (RU)\n"
            f"Платформа: {plat} | Роль: {role} | Режим: {diff}\n"
            "Стартовые цифры (потом докручиваем 60-сек тестом):",
            [
                ("Deadzone L Min", "0.00–0.05 (до исчезновения дрифта)"),
                ("Deadzone R Min", rmin),
                ("Trigger Deadzone", "0.00"),
                ("Response Curve Slope", slope),
                ("Vibration", "OFF (да, так лучше)"),
                ("Auto Sprint", "ON (если комфортно)"),
                ("Tactical Sprint Assist", "ON (если не ломает мувмент)"),
            ],
        )
        + _micro_test_block(diff)
        + _checklist_block()
        + "\n\n😈 Правило демона: ты не должен быть “быстрым”, ты должен быть “точным на скорости”."
    )


# =========================
# WARZONE — KBM TUNING (RU) — С ЦИФРАМИ + тест + чеклист
# =========================
def wz_kbm_tuning_text(profile: Dict[str, Any]) -> str:
    diff = _diff(profile)
    role = _role(profile)

    return (
        _fmt(
            "⌨️ Warzone — KBM Tuning (RU)\n"
            f"Роль: {role} | Режим: {diff}\n"
            "Цифры (база):",
            [
                ("DPI", "800"),
                ("Polling Rate", "1000 Hz"),
                ("Windows Enhance Pointer Precision", "OFF"),
                ("Raw Input", "ON (если есть в игре)"),
                ("In-game Sens старт", "5.5 (потом ±0.3 по тесту)"),
                ("ADS Multiplier", "1.00"),
                ("FOV", "110"),
            ],
        )
        + _micro_test_block(diff)
        + _checklist_block()
        + "\n\n😄 Юмор: если ты “чувствуешь” сенсу каждый день по-разному — проверь сон и кофе, а не DPI."
    )


# =========================
# WARZONE — MOVEMENT/POSITIONING (RU) — живо + структурно
# =========================
def wz_movement_positioning_text(profile: Dict[str, Any]) -> str:
    diff = _diff(profile)
    role = _role(profile)

    now = [
        "• 2–3 сек в простреле = ты сам подписал договор на смерть.",
        "• Урон дал → сместись. Килл сделал → сместись.",
        "• Репик одного угла = платная подписка на повторный килл противника.",
    ]
    if diff == "Demon":
        now += [
            "• Дай инфу плечом → пик на килл → сразу смена позиции.",
            "• Если ты стоишь на месте — ты не Demon, ты декорация.",
        ]
    elif diff == "Pro":
        now += [
            "• Позиция важнее эго: живи дольше, делай больше.",
        ]

    later = [
        "• Каждые 15 сек спрашивай: «Где мой выход?»",
        "• Нет выхода = ты уже труп, просто пока не понял.",
        "• После каждого файта: «если меня сейчас пушнут — куда откат?»",
    ]

    return (
        "🧠 Warzone — Мувмент/Позиционка (RU)\n\n"
        f"Роль: {role} | Режим: {diff}\n\n"
        "СЕЙЧАС (в бою):\n" + "\n".join(now) + "\n\n"
        "ДАЛЬШЕ (привычка):\n" + "\n".join(later) + "\n\n"
        "😄 Юмор: если у тебя нет плана отхода — поздравляю, твой план называется “умирать красиво”."
    )


# =========================
# WARZONE — AUDIO/VISUAL (RU) — коротко и полезно
# =========================
def wz_audio_visual_text(profile: Dict[str, Any]) -> str:
    return (
        "🎧 Warzone — Аудио/Видео (RU)\n\n"
        "Аудио:\n"
        "1) Сделай шаги читаемыми, но не режь весь микс в “песок”.\n"
        "2) Не меняй пресеты каждый день — мозг привыкает.\n"
        "3) Если слышишь всё, кроме врага — значит ты слышишь “шум”, а не “инфу”.\n\n"
        "Видео:\n"
        "1) Читаемость врага > кино.\n"
        "2) Меньше визуального мусора = быстрее реакция.\n\n"
        "😄 Юмор: если у тебя “самая красивая картинка”, но 0 киллов — ты оператор, а не игрок."
    )
