/* app/webapp/static/zombies3d.js */
(() => {
  "use strict";

  const safe = (fn) => { try { return fn(); } catch (_) { return undefined; } };

  function ensureStyles() {
    if (document.getElementById("bco3dStyles")) return;
    const css = document.createElement("style");
    css.id = "bco3dStyles";
    css.textContent = `
      .bco3d-root{position:fixed;inset:0;z-index:99999;background:#000;}
      .bco3d-canvas{width:100%;height:100%;touch-action:none;display:block;}
      .bco3d-hud{position:absolute;left:0;right:0;top:0;padding:calc(var(--tg-top,0px) + 10px) 12px 10px;display:flex;gap:10px;align-items:center;justify-content:space-between;font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;}
      .bco3d-pill{backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px); background:rgba(255,255,255,.08); border:1px solid rgba(255,255,255,.12); border-radius:14px; padding:8px 10px; color:rgba(255,255,255,.92); font-weight:700; font-size:12px; letter-spacing:.2px;}
      .bco3d-btn{cursor:pointer; user-select:none; -webkit-user-select:none; border:none; outline:none; border-radius:14px; padding:10px 12px; background:rgba(255,255,255,.10); color:#fff; font-weight:800; font-size:12px;}
      .bco3d-btn:active{transform:scale(.98);}
      .bco3d-joy{position:absolute; bottom:calc(var(--tg-bottom,0px) + 14px); width:150px; height:150px; border-radius:999px; background:rgba(255,255,255,.08); border:1px solid rgba(255,255,255,.12); backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px);}
      .bco3d-joy.left{left:14px;}
      .bco3d-joy.right{right:14px;}
      .bco3d-joy .knob{position:absolute; left:50%; top:50%; width:60px; height:60px; margin-left:-30px; margin-top:-30px; border-radius:999px; background:rgba(255,255,255,.18); border:1px solid rgba(255,255,255,.20);}
      .bco3d-toast{position:absolute; left:50%; transform:translateX(-50%); bottom:calc(var(--tg-bottom,0px) + 180px); padding:10px 12px; border-radius:14px; background:rgba(0,0,0,.55); border:1px solid rgba(255,255,255,.12); color:rgba(255,255,255,.92); font-weight:700; font-size:12px; opacity:0; transition:opacity .18s ease; pointer-events:none;}
      .bco3d-toast.show{opacity:1;}
    `;
    document.head.appendChild(css);
  }

  function toast(root, msg, ms = 1200) {
    const t = root.querySelector(".bco3d-toast");
    if (!t) return;
    t.textContent = String(msg || "");
    t.classList.add("show");
    setTimeout(() => t.classList.remove("show"), ms);
  }

  function makeJoystick(el) {
    const knob = el.querySelector(".knob");
    const st = { active: false, id: -1, x: 0, y: 0, ox: 0, oy: 0 };
    const radius = 55;

    function setKnob(dx, dy) {
      const len = Math.hypot(dx, dy);
      if (len > radius && len > 0) {
        dx = dx / len * radius;
        dy = dy / len * radius;
      }
      knob.style.transform = `translate(${dx}px, ${dy}px)`;
      st.x = dx / radius;
      st.y = dy / radius;
    }

    function reset() {
      st.active = false;
      st.id = -1;
      st.x = 0;
      st.y = 0;
      knob.style.transform = "translate(0px,0px)";
    }

    el.addEventListener("pointerdown", (e) => {
      st.active = true;
      st.id = e.pointerId;
      const r = el.getBoundingClientRect();
      st.ox = r.left + r.width / 2;
      st.oy = r.top + r.height / 2;
      setKnob(e.clientX - st.ox, e.clientY - st.oy);
      try { el.setPointerCapture(e.pointerId); } catch (_) {}
      e.preventDefault();
    }, { passive: false });

    el.addEventListener("pointermove", (e) => {
      if (!st.active || e.pointerId !== st.id) return;
      setKnob(e.clientX - st.ox, e.clientY - st.oy);
      e.preventDefault();
    }, { passive: false });

    el.addEventListener("pointerup", (e) => {
      if (e.pointerId !== st.id) return;
      reset();
      e.preventDefault();
    }, { passive: false });

    el.addEventListener("pointercancel", (e) => {
      if (e.pointerId !== st.id) return;
      reset();
    });

    return {
      get: () => ({ x: st.x, y: st.y }),
      reset
    };
  }

  function createRoot() {
    ensureStyles();
    const root = document.createElement("div");
    root.className = "bco3d-root";
    root.innerHTML = `
      <canvas class="bco3d-canvas" id="bco3dCanvas"></canvas>
      <div class="bco3d-hud">
        <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
          <div class="bco3d-pill" id="bco3dMode">3D • Roguelike</div>
          <div class="bco3d-pill" id="bco3dStats">HP 100 • K 0 • W 1</div>
        </div>
        <button class="bco3d-btn" id="bco3dExit">⟵ Exit</button>
      </div>
      <div class="bco3d-joy left"><div class="knob"></div></div>
      <div class="bco3d-joy right"><div class="knob"></div></div>
      <div class="bco3d-toast">OK</div>
    `;
    return root;
  }

  function start3D({ mode = "roguelike", map = "Ashes", onExit } = {}) {
    const BABYLON = window.BABYLON;
    if (!BABYLON) throw new Error("Babylon.js not found");

    const mount = document.getElementById("zOverlayMount") || document.body;
    const root = createRoot();
    mount.appendChild(root);

    const canvas = root.querySelector("#bco3dCanvas");
    const jL = makeJoystick(root.querySelector(".bco3d-joy.left"));
    const jR = makeJoystick(root.querySelector(".bco3d-joy.right"));

    // Scene
    const engine = new BABYLON.Engine(canvas, true, { preserveDrawingBuffer: false, stencil: false, antialias: true });
    const scene = new BABYLON.Scene(engine);
    scene.clearColor = new BABYLON.Color4(0, 0, 0, 1);

    const camera = new BABYLON.FreeCamera("cam", new BABYLON.Vector3(0, 8, -12), scene);
    camera.setTarget(new BABYLON.Vector3(0, 0, 0));
    camera.attachControl(canvas, true);
    camera.inputs.clear(); // mobile joystick only

    const light = new BABYLON.HemisphericLight("h", new BABYLON.Vector3(0, 1, 0), scene);
    light.intensity = 0.95;

    const ground = BABYLON.MeshBuilder.CreateGround("g", { width: 80, height: 80 }, scene);
    const gmat = new BABYLON.StandardMaterial("gmat", scene);
    gmat.diffuseColor = new BABYLON.Color3(0.06, 0.06, 0.09);
    gmat.specularColor = new BABYLON.Color3(0, 0, 0);
    ground.material = gmat;

    // Player
    const player = BABYLON.MeshBuilder.CreateSphere("p", { diameter: 1.2, segments: 16 }, scene);
    const pmat = new BABYLON.StandardMaterial("pm", scene);
    pmat.emissiveColor = new BABYLON.Color3(0.2, 0.9, 0.9);
    player.material = pmat;
    player.position.y = 0.6;

    // Simple weapon projectiles
    const bullets = [];

    // Enemies
    const enemies = [];

    let hp = 100;
    let kills = 0;
    let wave = 1;
    let coins = 0;

    function hud() {
      const s = root.querySelector("#bco3dStats");
      if (s) s.textContent = `HP ${hp} • K ${kills} • W ${wave} • C ${coins}`;
      const m = root.querySelector("#bco3dMode");
      if (m) m.textContent = `3D • ${mode === "arcade" ? "Arcade" : "Roguelike"} • ${map}`;
    }

    function spawnEnemy() {
      const e = BABYLON.MeshBuilder.CreateBox("z", { size: 1.1 }, scene);
      const em = new BABYLON.StandardMaterial("zm", scene);
      em.emissiveColor = new BABYLON.Color3(0.85, 0.2, 0.25);
      e.material = em;
      const r = 28;
      const a = Math.random() * Math.PI * 2;
      e.position.set(Math.cos(a) * r, 0.55, Math.sin(a) * r);
      enemies.push({ mesh: e, spd: 0.018 + 0.0025 * wave, hp: 1 + Math.floor(wave / 3) });
    }

    function spawnWave() {
      const n = mode === "arcade" ? (4 + wave * 2) : (6 + wave * 3);
      for (let i = 0; i < n; i++) spawnEnemy();
      toast(root, `Wave ${wave}`);
    }

    function shoot(dirX, dirY) {
      // dir vector from right stick (x,y where y forward/back)
      const v = new BABYLON.Vector3(dirX, 0, dirY);
      if (v.lengthSquared() < 0.05) return;
      v.normalize();
      const b = BABYLON.MeshBuilder.CreateSphere("b", { diameter: 0.25, segments: 8 }, scene);
      const bm = new BABYLON.StandardMaterial("bm", scene);
      bm.emissiveColor = new BABYLON.Color3(0.95, 0.95, 0.35);
      b.material = bm;
      b.position = player.position.add(new BABYLON.Vector3(0, 0.2, 0));
      bullets.push({ mesh: b, vel: v.scale(0.55), life: 0 });
    }

    let shootCooldown = 0;

    function end(reason) {
      try { engine.stopRenderLoop(); } catch (_) {}
      try { scene.dispose(); } catch (_) {}
      try { engine.dispose(); } catch (_) {}
      try { root.remove(); } catch (_) {}
      safe(() => onExit && onExit());

      // Report to MiniApp bridge if present
      safe(() => {
        const payload = {
          action: "game_result",
          game: "zombies_3d",
          mode,
          map,
          kills,
          wave,
          coins,
          duration_ms: Math.round((Date.now() - startedAt) || 0),
          reason: reason || "exit"
        };
        if (window.BCO_APP?.sendToBot) window.BCO_APP.sendToBot({ ...payload, profile: true });
      });
    }

    const startedAt = Date.now();
    spawnWave();
    hud();

    root.querySelector("#bco3dExit").addEventListener("click", () => end("exit"));

    engine.runRenderLoop(() => {
      const dt = engine.getDeltaTime() / 16.666;

      // Movement (left stick)
      const mv = jL.get();
      const spd = (mode === "arcade" ? 0.14 : 0.12) * dt;
      player.position.x += mv.x * spd;
      player.position.z += mv.y * spd;

      // Camera follow
      camera.position.x = player.position.x;
      camera.position.z = player.position.z - 12;
      camera.position.y = 8;
      camera.setTarget(player.position);

      // Aim/shoot (right stick)
      const aim = jR.get();
      shootCooldown -= dt;
      if (shootCooldown <= 0 && (aim.x * aim.x + aim.y * aim.y) > 0.12) {
        // right stick y is up/down in screen, map to forward/back in world
        shoot(aim.x, aim.y);
        shootCooldown = 0.18; // ~5.5 rps
      }

      // Update bullets
      for (let i = bullets.length - 1; i >= 0; i--) {
        const b = bullets[i];
        b.life += dt;
        b.mesh.position.addInPlace(b.vel.scale(dt));
        if (b.life > 45) {
          b.mesh.dispose();
          bullets.splice(i, 1);
        }
      }

      // Update enemies
      for (let i = enemies.length - 1; i >= 0; i--) {
        const e = enemies[i];
        const dir = player.position.subtract(e.mesh.position);
        dir.y = 0;
        const dist = dir.length();
        if (dist > 0.0001) {
          dir.normalize();
          e.mesh.position.addInPlace(dir.scale(e.spd * dt * 2.1));
        }

        // Damage player
        if (dist < 1.0) {
          hp -= (mode === "arcade" ? 1 : 2);
          e.mesh.position.addInPlace(dir.scale(-0.5));
          if (hp <= 0) {
            toast(root, "DOWN", 900);
            end("dead");
            return;
          }
        }
      }

      // Bullet hits
      for (let i = bullets.length - 1; i >= 0; i--) {
        const b = bullets[i];
        for (let j = enemies.length - 1; j >= 0; j--) {
          const e = enemies[j];
          if (b.mesh.intersectsMesh(e.mesh, false)) {
            e.hp -= 1;
            b.mesh.dispose();
            bullets.splice(i, 1);
            if (e.hp <= 0) {
              kills += 1;
              coins += (mode === "arcade" ? 1 : 2);
              e.mesh.dispose();
              enemies.splice(j, 1);
              if (mode === "roguelike" && Math.random() < 0.05) {
                hp = Math.min(120, hp + 6);
              }
            }
            break;
          }
        }
      }

      // Next wave
      if (enemies.length === 0) {
        wave += 1;
        if (mode === "roguelike") {
          hp = Math.min(140, hp + 8);
          coins += 6 + Math.floor(wave / 2);
        }
        spawnWave();
      }

      hud();
      scene.render();
    });

    // Resize
    const onResize = () => safe(() => engine.resize());
    window.addEventListener("resize", onResize);

    // Safety cleanup if root removed
    const mo = new MutationObserver(() => {
      if (!document.body.contains(root)) {
        window.removeEventListener("resize", onResize);
        try { mo.disconnect(); } catch (_) {}
      }
    });
    safe(() => mo.observe(document.body, { childList: true, subtree: true }));

    toast(root, "Dual-stick: move (L) • aim/shoot (R)");
  }

  window.BCO_ZOMBIES_3D = {
    start: start3D
  };
})();
