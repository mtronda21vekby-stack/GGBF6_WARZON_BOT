# -*- coding: utf-8 -*-
from __future__ import annotations

ROLES = {
    "entry": {
        "label": "⚡ Entry",
        "desc": "Агрессия, первые пики, трейды",
        "style": {
            "normal": "Играем агрессивно, но с выходом.",
            "pro": "Контролируй тайминги и трейды.",
            "demon": "Ты первый. Ошибка = смерть. Дави сразу."
        }
    },
    "anchor": {
        "label": "🛡 Anchor",
        "desc": "Удержание позиции, инфа",
        "style": {
            "normal": "Держи позицию и отход.",
            "pro": "Не жадничай — твоя задача жить.",
            "demon": "Ты последний барьер. Не дрогни."
        }
    },
    "sniper": {
        "label": "🎯 Sniper",
        "desc": "Дистанция, терпение, контроль",
        "style": {
            "normal": "Играй от дистанции.",
            "pro": "Меняй угол после каждого выстрела.",
            "demon": "Один выстрел — одна смерть."
        }
    },
    "support": {
        "label": "🧠 Support",
        "desc": "Инфа, утилити, контроль",
        "style": {
            "normal": "Помогай команде.",
            "pro": "Контролируй поле боя.",
            "demon": "Ты дирижёр хаоса."
        }
    }
}


def kb_roles() -> dict:
    return {
        "keyboard": [
            [{"text": ROLES["entry"]["label"]}, {"text": ROLES["anchor"]["label"]}],
            [{"text": ROLES["sniper"]["label"]}, {"text": ROLES["support"]["label"]}],
            [{"text": "⬅️ Назад"}],
        ],
        "resize_keyboard": True,
        "is_persistent": True,
    }


def role_from_text(text: str) -> str | None:
    for k, v in ROLES.items():
        if v["label"] == text:
            return k
    return None
